import File from "../models/File.js";

export const uploadFile = async (req, res) => {
  try {
    const { originalName } = req.body;

    const record = await File.create({
      userId: req.user.id,
      filename: originalName,
      originalUrl: `/uploads/${req.files.original[0].filename}`,
      processedUrl: `/uploads/${req.files.processed[0].filename}`,
    });

    res.json({ msg: "Files uploaded successfully", file: record });
  } catch (error) {
    res.status(500).json({ msg: "Upload failed" });
  }
};

export const getGallery = async (req, res) => {
  try {
    const files = await File.find({ userId: req.user.id }).sort({ createdAt: -1 });
    res.json(files);
  } catch (error) {
    res.status(500).json({ msg: "Failed to fetch gallery" });
  }
};
